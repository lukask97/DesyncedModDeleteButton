local package = ...

package.includes = {
	"icons.lua",
	--"components.lua", --planned
	"util.lua",
	"framedelete.lua",

}
-- called when mod is initializing
function package:init()
end





