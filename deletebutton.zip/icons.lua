data.brushes.m_icon50_delete = "DeleteButton/textures/delete50.png"
